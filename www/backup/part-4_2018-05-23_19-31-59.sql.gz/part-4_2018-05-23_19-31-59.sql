#SXD20|20011|50638|50538|2018.05.23 19:31:59|part-4|0|1|1|
#TA about`1`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`about`utf8_general_ci	;
INSERT INTO `about` VALUES 
(1,'Egor Kazakov','Я веб-разработчик')	;
