#SXD20|20011|50638|50538|2018.05.26 21:49:33|part-4|0|2|4|
#TA about`1`16384|users`3`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`about`utf8_general_ci	;
INSERT INTO `about` VALUES 
(1,'Egor Kazakov','Я веб-разработчик')	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secundname` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `secondname` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'dvoen@rightblog.ru','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Dimitar ','Ключевский','','China','Bogor','admin','Georgiev'),
(2,'dvoenskok@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Super_Dimi','','','China','Bogor','user','Georgiev'),
(3,'ironman@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','','','','','','user',\N)	;
