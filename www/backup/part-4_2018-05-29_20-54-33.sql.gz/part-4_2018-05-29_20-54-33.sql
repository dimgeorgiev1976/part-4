#SXD20|20011|50638|50538|2018.05.29 20:54:33|part-4|0|2|5|
#TA about`0`16384|users`5`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secundname` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `secondname` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `avatar_small` varchar(191) DEFAULT NULL,
  `recovery_code` varchar(191) DEFAULT NULL,
  `recovery_code_times` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'dvoen@rightblog.ru','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Dimitar ','Georgiev','','China','Bogor','admin','Georgiev',\N,\N,\N,\N),
(2,'dvoenskok@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Super_Dimi','','','China','Bogor','user','Georgiev','103527254.jpg','48-103527254.jpg','k4MrviPhRF7SUnx',3),
(3,'ironman@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','','','','','','user',\N,\N,\N,'bNmfuiswIcdUXPS',3),
(4,'info@rightblog.ru','$2y$10$p6gxwU2DTQD2Aqclt7aGdeU3JSN7AY//5agUZwbaxGM6lM0RyQKB.','','','','','','user',\N,\N,\N,\N,\N),
(5,'test@rightblog.ru','$2y$10$m4BY/7Z77rTzT6eXjhuO4.ihc6nzIrRtdtTJ6C.co/PC5upHF/qf6','Tony ','','','Russia','Bali','user','Stark','-316729632.jpg','48--316729632.jpg','8eJjzPwyLvpGMs3',0)	;
