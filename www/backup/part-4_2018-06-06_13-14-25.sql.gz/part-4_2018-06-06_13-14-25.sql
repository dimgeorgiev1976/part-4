#SXD20|20011|50638|50538|2018.06.06 13:14:25|part-4|0|4|14|
#TA about`0`16384|comments`4`16384|posts`6`16384|users`4`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`comments`utf8mb4_unicode_520_ci	;
CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_comments_post` (`post_id`),
  KEY `index_foreignkey_comments_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`comments`utf8mb4_unicode_520_ci	;
INSERT INTO `comments` VALUES 
(2,6,3,'Первий коментарий','2018-05-31 15:59:34'),
(6,4,3,'HI','2018-05-31 16:18:27'),
(7,4,3,'Привет Мир!','2018-06-01 10:23:56'),
(11,6,4,'Jena De','2018-06-06 12:26:32')	;
#	TC`posts`utf8mb4_unicode_520_ci	;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` int(11) unsigned DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_posts_author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`posts`utf8mb4_unicode_520_ci	;
INSERT INTO `posts` VALUES 
(3,'Новый пост # 3','Введите город','-16613913.jpg','320--16613913.jpg',1,'2018-06-04 15:56:57'),
(4,'Новый пост # 4','Bogor','545606424.jpg','320-545606424.jpg',1,'2018-06-04 15:56:57'),
(5,'Новый пост # 5','Yogiakarta','1063470595.jpg','320-1063470595.jpg',1,'2018-06-04 15:56:57'),
(6,'Новый пост # 6','lombol','789743237.jpg','320-789743237.jpg',1,'2018-06-04 15:56:57'),
(7,'Новый пост # 13','Java','-294314350.jpg','320--294314350.jpg',1,'2018-06-04 15:56:57'),
(9,'Новый пост','Введите город','360709998.jpg','320-360709998.jpg',1,'2018-06-05 14:57:51')	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secundname` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `secondname` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `avatar_small` varchar(191) DEFAULT NULL,
  `recovery_code` varchar(191) DEFAULT NULL,
  `recovery_code_times` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'dvoen@rightblog.ru','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Dimitar ','Georgiev','','China','Bogor','admin','Georgiev','551595692.jpg','48-551595692.jpg',\N,\N),
(2,'dvoenskok@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Super_Dimi','','','China','Bogor','user','Georgiev','103527254.jpg','48-103527254.jpg','k4MrviPhRF7SUnx',3),
(3,'ironman@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','taco','','','Ghana','Siatle','user','Stark','-256955547.png','48--256955547.png','bNmfuiswIcdUXPS',3),
(4,'info@rightblog.ru','$2y$10$p6gxwU2DTQD2Aqclt7aGdeU3JSN7AY//5agUZwbaxGM6lM0RyQKB.','John','','','Ghan','','user','Do','1017335438.jpg','48-1017335438.jpg',\N,\N),
(5,'test@rightblog.ru','$2y$10$m4BY/7Z77rTzT6eXjhuO4.ihc6nzIrRtdtTJ6C.co/PC5upHF/qf6','Tony ','','','Russia','Bali','user','Stark','-316729632.jpg','48--316729632.jpg','8eJjzPwyLvpGMs3',0)	;
