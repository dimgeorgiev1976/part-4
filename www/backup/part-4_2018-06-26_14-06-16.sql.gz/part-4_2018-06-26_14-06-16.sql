#SXD20|20011|50638|50538|2018.06.26 14:06:16|part-4|0|8|38|
#TA about`1`16384|categories`3`16384|comments`4`16384|contacts`0`16384|messages`9`16384|posts`8`16384|technologies`8`16384|users`5`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`about`utf8_general_ci	;
INSERT INTO `about` VALUES 
(1,'Dimitar Georgiev','Hello!','802907768.jpg')	;
#	TC`categories`utf8mb4_unicode_520_ci	;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`categories`utf8mb4_unicode_520_ci	;
INSERT INTO `categories` VALUES 
(1,'Speakings'),
(2,'Traveling'),
(3,'Покупки'),
(6,'Lesson programing')	;
#	TC`comments`utf8mb4_unicode_520_ci	;
CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_comments_post` (`post_id`),
  KEY `index_foreignkey_comments_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`comments`utf8mb4_unicode_520_ci	;
INSERT INTO `comments` VALUES 
(2,6,3,'Первий коментарий','2018-05-31 15:59:34'),
(6,4,3,'HI','2018-05-31 16:18:27'),
(7,4,3,'Привет Мир!','2018-06-01 10:23:56'),
(11,6,4,'Jena De','2018-06-06 12:26:32')	;
#	TC`contacts`utf8_general_ci	;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `vk` varchar(255) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `github` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`messages`utf8mb4_unicode_520_ci	;
CREATE TABLE `messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message_file` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message_file_name_original` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`messages`utf8mb4_unicode_520_ci	;
INSERT INTO `messages` VALUES 
(1,'dvoen@rightblog.ru','messages','Tony Stark',\N,\N,\N),
(2,'info@rightblog.ru','Privet','Dimitar Georgiev','1159061691.html',\N,\N),
(3,'info@rightblog.ru','Privet','Dimitar Georgiev','-423824867.html',\N,\N),
(4,'test@rightblog.ru','Hello!','Super_Dimi','568851902.html',\N,\N),
(5,'dvoen@rightblog.ru','HI!','Tony Stark','13806827.png','Photo.png',\N),
(6,'test@rightblog.ru','TEST @','Dimitar Georgiev','700378608.png',\N,\N),
(7,'dvoen@rightblog.ru','Prikrepen fail','Tony Stark','1150937634.pdf',\N,\N),
(8,'test@rightblog.ru','Fail message_file_name_original','Super_Dimi','1100355001.pdf','Transaction.pdf',\N),
(9,'info@rightblog.ru','New message date','Super_Dimi','1171929723.pdf','application802960107120.pdf','2018-06-23 08:55:39')	;
#	TC`posts`utf8mb4_unicode_520_ci	;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` int(11) unsigned DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `cat` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_posts_author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`posts`utf8mb4_unicode_520_ci	;
INSERT INTO `posts` VALUES 
(3,'Новый пост # 3','Введите город','-16613913.jpg','320--16613913.jpg',1,'2018-06-04 15:56:57',\N,'3'),
(4,'Новый пост # 4','Bogor','545606424.jpg','320-545606424.jpg',1,'2018-06-04 15:56:57',\N,'3'),
(5,'Новый пост # 5','Yogiakarta','1063470595.jpg','320-1063470595.jpg',1,'2018-06-04 15:56:57',\N,'1'),
(6,'Новый пост # 6','lombol','789743237.jpg','320-789743237.jpg',1,'2018-06-04 15:56:57',\N,'2'),
(7,'Новый пост # 13','Java','-294314350.jpg','320--294314350.jpg',1,'2018-06-04 15:56:57',\N,'2'),
(9,'Новый пост','Введите город','360709998.jpg','320-360709998.jpg',1,'2018-06-05 14:57:51',\N,'3'),
(10,'Категория','China','-220249040.JPG','320--220249040.JPG',1,'2018-06-18 21:39:53',1529347193,'1'),
(11,'Категория','China','-317263329.JPG','320--317263329.JPG',1,'2018-06-18 21:40:26',1529347226,'1'),
(12,'Категория','China','588183600.jpg','320-588183600.jpg',1,'2018-06-18 21:41:22',1529347282,'2')	;
#	TC`technologies`utf8_general_ci	;
CREATE TABLE `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `success` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`technologies`utf8_general_ci	;
INSERT INTO `technologies` VALUES 
(1,'HTML5',100),
(2,'CSS3',100),
(3,'JS',75),
(4,'JQuery',75),
(5,'PHP',50),
(6,'MySQL',50),
(7,'Git',70),
(8,'Gulp',80),
(9,'Bower',90),
(10,'WebPack',20)	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secundname` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `secondname` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `avatar_small` varchar(191) DEFAULT NULL,
  `recovery_code` varchar(191) DEFAULT NULL,
  `recovery_code_times` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'dvoen@rightblog.ru','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Dimitar ','Georgiev','','China','Bogor','admin','Georgiev','551595692.jpg','48-551595692.jpg',\N,\N),
(2,'dvoenskok@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Super_Dimi','','','China','Bogor','user','Georgiev','103527254.jpg','48-103527254.jpg','k4MrviPhRF7SUnx',3),
(3,'ironman@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','taco','','','Ghana','Siatle','user','Stark','-256955547.png','48--256955547.png','bNmfuiswIcdUXPS',3),
(4,'info@rightblog.ru','$2y$10$p6gxwU2DTQD2Aqclt7aGdeU3JSN7AY//5agUZwbaxGM6lM0RyQKB.','John','','','Ghan','','user','Do','1017335438.jpg','48-1017335438.jpg',\N,\N),
(5,'test@rightblog.ru','$2y$10$m4BY/7Z77rTzT6eXjhuO4.ihc6nzIrRtdtTJ6C.co/PC5upHF/qf6','Tony ','','','Russia','Bali','user','Stark','-316729632.jpg','48--316729632.jpg','8eJjzPwyLvpGMs3',0),
(6,'abtarar@email.ru','$2y$10$P6OH8QXM.OShX0beUTqyWeKmb3JQkgKI6h1K/RkwPFf.cDZA04EJC','Tony ','','','Russia','Siatle','user','Stark_Ok','-234421665.JPG','48--234421665.JPG',\N,\N)	;
