#SXD20|20011|50638|50538|2018.07.25 19:24:03|part-4|0|11|61|
#TA about`1`16384|categories`3`16384|comments`11`16384|contacts`1`16384|jobs`2`16384|messages`13`16384|posts`12`16384|skills`1`16384|technologies`8`16384|users`9`16384|works`0`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`about`utf8_general_ci	;
INSERT INTO `about` VALUES 
(1,'Dimitar Georgiev','<p>Я веб разработчик из Казани. Мне 42 лет. Занимаюсь разработкой современных сайтов и приложений. Мне нравится делать интересные и современные проекты. Этот сайт я сделал в рамках обучения в школе онлайн обучения WebCademy. Чуть позже я освежу в нём свой контент. А пока посмотрите, как тут всё классно и красиво! Что я умею Меня привлекет Frontend разработка, это не только моя работа, но и хобби.Также знаком и могу решать не сложные задачи на Backend. Знаком и использую современный workflow, работаю с репозиториями git и сборкой проекта на gulp.</p>\r\n','731807443.jpg')	;
#	TC`categories`utf8mb4_unicode_520_ci	;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`categories`utf8mb4_unicode_520_ci	;
INSERT INTO `categories` VALUES 
(1,'Speakings'),
(2,'Traveling'),
(3,'Покупки')	;
#	TC`comments`utf8mb4_unicode_520_ci	;
CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_520_ci,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_comments_post` (`post_id`),
  KEY `index_foreignkey_comments_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`comments`utf8mb4_unicode_520_ci	;
INSERT INTO `comments` VALUES 
(2,6,3,'Первий коментарий','2018-05-31 15:59:34'),
(6,4,3,'HI','2018-05-31 16:18:27'),
(7,4,3,'Привет Мир!','2018-06-01 10:23:56'),
(11,6,4,'Jena De','2018-06-06 12:26:32'),
(12,12,1,'123','2018-07-02 13:54:36'),
(13,9,1,'Tedi see this!','2018-07-02 13:55:16'),
(14,13,1,'First comment !','2018-07-13 16:46:42'),
(15,13,3,'howdie !','2018-07-21 17:26:05'),
(16,13,3,'<figure class=\"easyimage easyimage-full\"><img alt=\"\" src=\"blob:http://part-4/66a69bf5-b3e3-44c8-9767-0d858eb253f7\" style=\"width:48px\" />\r\n<figcaption></figcaption>\r\n</figure>\r\n\r\n<p>&nbsp;</p>\r\n','2018-07-21 17:48:44'),
(17,13,3,'<h3>Иными словами, аллегро варьирует хамбакер, на этих моментах останавливаются Л.А.Мазель и В.А.Цуккерман в своем &quot;Анализе музыкальных произведений&quot;. Иными словами, мнимотакт начинает самодостаточный фьюжн, и здесь мы видим ту самую каноническую секвенцию с разнонаправленным шагом отдельных звеньев. Драм-машина mezzo forte варьирует паузный септаккорд. Громкостнoй прогрессийный период имеет нечетный соноропериод. Адажио начинает звукосниматель.</h3>\r\n','2018-07-21 17:51:46'),
(18,13,3,'<figure class=\"easyimage easyimage-full\"><img alt=\"\" src=\"blob:http://part-4/8ad771e5-47a5-443f-bbd2-cc6eae28cd93\" style=\"width:48px\" />\r\n<figcaption></figcaption>\r\n</figure>\r\n\r\n<p>&nbsp;</p>\r\n','2018-07-21 17:52:10')	;
#	TC`contacts`utf8_general_ci	;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `vk` varchar(255) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `github` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`contacts`utf8_general_ci	;
INSERT INTO `contacts` VALUES 
(1,'info@rightblock.ru','ironman','http://vk.com/ironman','http://fb.com/ironman','+359878818754','11 Victoria Street, Belfast, UK Cathedral Qtr\r\n','Dimitar ','Georgiev                                    ','http://github.com','http://twitter.com/',43.627282,122.257714)	;
#	TC`jobs`utf8mb4_unicode_520_ci	;
CREATE TABLE `jobs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`jobs`utf8mb4_unicode_520_ci	;
INSERT INTO `jobs` VALUES 
(3,'сентябрь 2015 &mdash; январь 2017','Разработчик интерфейсов, Яндекс','Работы в проекте Яндекс Музыка. Создание новых разделов сервиса. Оптимизация и создание новых компонентов платформы.'),
(4,'март 2013 &mdash; август 2015','Веб-разработчик, Cloud studio','Frontend и Backend для клиентских проектов студии. Работа над студийной CMS для интернет магазинов. Участие в разработке CRM системы &ldquo;Sky CRM&rdquo;. Стек используемых технологий: Git, JS, Angular'),
(5,'март 2017 &mdash; по настоящее время','Верстальщик, Супер сайт','Frontend разработчик, Вконтактe, mail.ru group\r\nРаботы в команде Вконтакте. Работал в команде над обновление сервиса Музыка,')	;
#	TC`messages`utf8mb4_unicode_520_ci	;
CREATE TABLE `messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci,
  `name` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message_file` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message_file_name_original` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`messages`utf8mb4_unicode_520_ci	;
INSERT INTO `messages` VALUES 
(2,'info@rightblog.ru','Privet','Dimitar Georgiev','1159061691.html',\N,\N),
(3,'info@rightblog.ru','Privet','Dimitar Georgiev','-423824867.html',\N,\N),
(4,'test@rightblog.ru','Hello!','Super_Dimi','568851902.html',\N,\N),
(5,'dvoen@rightblog.ru','HI!','Tony Stark','13806827.png','Photo.png',\N),
(6,'test@rightblog.ru','TEST @','Dimitar Georgiev','700378608.png',\N,\N),
(7,'dvoen@rightblog.ru','Prikrepen fail','Tony Stark','1150937634.pdf',\N,\N),
(8,'test@rightblog.ru','Fail message_file_name_original','Super_Dimi','1100355001.pdf','Transaction.pdf',\N),
(9,'info@rightblog.ru','New message date','Super_Dimi','1171929723.pdf','application802960107120.pdf','2018-06-23 08:55:39'),
(10,'ironman@gmail.com','profile/profile-edit.tpl','Tony ','167333717.jpg','arnaud-mesureur-186867-unsplash.jpg','2018-07-06 11:50:28'),
(11,'dvoen@rightblog.ru','Fail upload','Youri','3370082.jpg','35305541283_c04f9db96c_o.jpg','2018-07-13 20:46:03'),
(12,'test@rightblog.ru','1144444444','Dimitar Georgiev','360591399.png','2018-02-24 (1).png','2018-07-14 21:40:24'),
(13,'TheThingsSheSaid@gmail.com','<p>Адажио синхронно вызывает фьюжн, а после исполнения Утесовым роли Потехина в &quot;Веселых ребятах&quot; слава артиста стала всенародной. Ощущение мономерности ритмического движения возникает, как правило, в условиях темповой стабильности, тем не менее пауза монотонно имитирует мономерный доминантсептаккорд. Алеаторически выстроенный бесконечный канон с полизеркальной векторно-голосовой структурой, и это особенно заметно у Чарли Паркера или Джона Колтрейна, интенсивен. Форма использует глубокий пласт.</p>\r\n\r\n<figure class=\"easyimage easyimage-full\"><img alt=\"\" src=\"blob:http://part-4/4445c559-629e-43c6-8fdf-1ffbe603dc13\" style=\"width:48px\" />\r\n<figcaption></figcaption>\r\n</figure>\r\n\r\n<p>&nbsp;</p>\r\n','Джона Колтрейна',\N,\N,'2018-07-21 17:35:26'),
(14,' TheThingsSheSaid@gmail.com','<p>Песня &quot;All The Things She Said&quot; (в русском варианте - &quot;Я сошла с ума&quot;) использует резкий рефрен, о чем подробно говорится в книге М.Друскина &quot;Ганс Эйслер и рабочее музыкальн<a id=\"Джона Колтрейна\" name=\"Джона Колтрейна\"></a>ое движение в Германии&quot;. Звукосниматель иллюстрирует мономерный соноропериод. Говорят также о фактуре, типичной для тех или иных жанров (&quot;фактура походного марша&quot;, &quot;фактура вальса&quot; и пр.), и здесь мы видим, что внутридискретное арпеджио диссонирует резкий доминантсепт<strong>аккорд, таким образом конструктивное состояние всей музыкальной ткани или какой-</strong>либо из составляющих ее субструктур (в том числе: временнoй, гармонической, динамической, тембровой, темповой) возникает как следствие их выстраивания на основе определенного ряда (модуса).</p>\r\n','Джона Колтрейна ','1145007665.jpg','94965010@N04.jpg','2018-07-21 17:38:59')	;
#	TC`posts`utf8mb4_unicode_520_ci	;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_520_ci,
  `post_img` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` int(11) unsigned DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `cat` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_posts_author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`posts`utf8mb4_unicode_520_ci	;
INSERT INTO `posts` VALUES 
(3,'Новый пост # 3','Введите город','-625088007.jpg','320--625088007.jpg',1,'2018-06-04 15:56:57',\N,'3'),
(4,'Новый пост # 4','Bogor','545606424.jpg','320-545606424.jpg',1,'2018-06-04 15:56:57',\N,'3'),
(5,'Новый пост # 5','<p>Yogiakarta</p>\r\n','1063470595.jpg','320-1063470595.jpg',1,'2018-06-04 15:56:57',\N,'1'),
(6,'Новый пост # 6','lombol','789743237.jpg','320-789743237.jpg',1,'2018-06-04 15:56:57',\N,'2'),
(7,'Новый пост # 13','','-451695720.jpg','320--451695720.jpg',1,'2018-06-04 15:56:57',\N,'2'),
(9,'Новый пост','Введите город','-193267682.JPG','320--193267682.JPG',1,'2018-06-05 14:57:51',\N,'3'),
(10,'Категория','China','-220249040.JPG','320--220249040.JPG',1,'2018-06-18 21:39:53',1529347193,'1'),
(11,'Категория','China','-290341271.jpg','320--290341271.jpg',1,'2018-06-18 21:40:26',1529347226,'1'),
(12,'Категория','China','588183600.jpg','320-588183600.jpg',1,'2018-06-18 21:41:22',1529347282,'2'),
(13,'Новый пост','Burgas','383243880.jpg','320-383243880.jpg',1,'2018-07-13 16:45:39',1531489539,'2'),
(14,'Новый пост','<h1>Реферат по музыковедению</h1>\r\n\r\n<p><strong>Тема: &laquo;Автономный лайн-ап: ретро или протяженность?&raquo;</strong></p>\r\n\r\n<p><big>Развивая эту тему, драм-машина диссонирует мнимотакт. Попса продолжает хорус, хотя это довольно часто напоминает <strong>песни Джима Моррисона и Патти Смит.</strong></big></p>\r\n','-263004115.jpg','320--263004115.jpg',1,'2018-07-21 16:56:34',1532181394,'3'),
(15,'Новый пост','<p>Введите город</p>\r\n','936213466.jpg','320-936213466.jpg',1,'2018-07-23 12:05:31',1532336731,'3')	;
#	TC`skills`utf8_general_ci	;
CREATE TABLE `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `html5` int(11) NOT NULL,
  `css3` int(11) NOT NULL,
  `js` int(11) NOT NULL,
  `jquery` int(11) NOT NULL,
  `php` int(11) NOT NULL,
  `mysql` int(11) NOT NULL,
  `git` int(11) NOT NULL,
  `gulp` int(11) NOT NULL,
  `bower` int(11) NOT NULL,
  `webpack` int(11) NOT NULL,
  `html` int(11) unsigned DEFAULT NULL,
  `css` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`skills`utf8_general_ci	;
INSERT INTO `skills` VALUES 
(1,50,0,80,60,60,10,60,10,90,60,50,'')	;
#	TC`technologies`utf8_general_ci	;
CREATE TABLE `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `success` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`technologies`utf8_general_ci	;
INSERT INTO `technologies` VALUES 
(1,'HTML5',100),
(2,'CSS3',100),
(3,'JS',75),
(4,'JQuery',75),
(5,'PHP',50),
(6,'MySQL',50),
(7,'Git',70),
(8,'Gulp',80),
(9,'Bower',90),
(10,'WebPack',20)	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secundname` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `secondname` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `avatar_small` varchar(191) DEFAULT NULL,
  `recovery_code` varchar(191) DEFAULT NULL,
  `recovery_code_times` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'dvoen@rightblog.ru','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Dimitar ','Georgiev','','China','Bogor','admin','Georgiev','551595692.jpg','48-551595692.jpg',\N,\N),
(2,'dvoenskok@gmail.com','$2y$10$LS9JGvoYdQpl15vjSWI6ru.FCqXbpREWUUlmJJANbWnBqR/aELaXe','Super_Dimi','','','China','Bogor','user','Georgiev','103527254.jpg','48-103527254.jpg','bAyIz2pqnoXJUgx',0),
(3,'ironman@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','taco','','','Ghana','Siatle','user','Stark','-256955547.png','48--256955547.png','bNmfuiswIcdUXPS',3),
(4,'info@rightblog.ru','$2y$10$p6gxwU2DTQD2Aqclt7aGdeU3JSN7AY//5agUZwbaxGM6lM0RyQKB.','John','','','Ghan','','user','Do','1017335438.jpg','48-1017335438.jpg','dAswxgXSyq1CWfu',3),
(5,'test@rightblog.ru','$2y$10$x50rEp.xVzTkcKYePPgAZ.dEA5mj62oSZisBrHc.IfcGYAQX8Oje.','Tony ','','','Russia','Bali','user','Stark','-316729632.jpg','48--316729632.jpg','Op3hUA6gmajbfND',3),
(6,'abtarar@email.ru','$2y$10$P6OH8QXM.OShX0beUTqyWeKmb3JQkgKI6h1K/RkwPFf.cDZA04EJC','Tony ','','','Russia','Siatle','user','Stark_Ok','-234421665.JPG','48--234421665.JPG',\N,\N),
(7,'111info@rightblog.ru','$2y$10$IXUdJLTyCatyMK96rsKAquSBTU6xelOGu6b5AK/qm.gZXrbSUMAgu','','','','','','user',\N,\N,\N,\N,\N),
(8,'123456info@rightblog.ru','$2y$10$guBEbZaiRUubKFH6wxs0SepXoDd.9jE22urK.LqY3VGpWcAYTuh0y','','','','','','user',\N,\N,\N,\N,\N),
(9,'123@rightblog.ru','$2y$10$.FL4.YzhfYpm3BylOyI4Je1gWi4coDgY3F1wqHz5fS6XJHEWxmYjO','','','','','','user',\N,\N,\N,\N,\N)	;
#	TC`works`utf8_general_ci	;
CREATE TABLE `works` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `cat` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  `author_Id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` varchar(255) NOT NULL,
  `github` varchar(255) NOT NULL,
  `period` varchar(191) NOT NULL,
  `technologies` varchar(255) NOT NULL,
  `project` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
