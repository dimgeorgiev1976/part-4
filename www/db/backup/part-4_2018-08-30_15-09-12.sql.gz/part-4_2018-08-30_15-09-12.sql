#SXD20|20011|50638|50538|2018.08.30 15:09:12|part-4|0|11|69|
#TA about`1`16384|categories`4`16384|comments`10`16384|contacts`1`16384|jobs`3`16384|messages`11`16384|posts`14`16384|skills`1`16384|technologies`8`16384|users`12`16384|works`4`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`about`utf8_general_ci	;
INSERT INTO `about` VALUES 
(1,'Dimitar Georgiev','<p>Я веб разработчик из Казани. Мне 42 лет. Занимаюсь разработкой современных сайтов и приложений. Мне нравится делать интересные и современные проекты. Этот сайт я сделал в рамках обучения в школе онлайн обучения WebCademy. Чуть позже я освежу в нём свой контент. А пока посмотрите, как тут всё классно и красиво! Что я умею Меня привлекет Frontend разработка, это не только моя работа, но и хобби.Также знаком и могу решать не сложные задачи на Backend. Знаком и использую современный workflow, работаю с репозиториями git и сборкой проекта на gulp.</p>\r\n','731807443.jpg')	;
#	TC`categories`utf8mb4_unicode_520_ci	;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`categories`utf8mb4_unicode_520_ci	;
INSERT INTO `categories` VALUES 
(1,'Speakings'),
(2,'Traveling'),
(3,'Покупки')	;
#	TC`comments`utf8mb4_unicode_520_ci	;
CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_520_ci,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_comments_post` (`post_id`),
  KEY `index_foreignkey_comments_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`comments`utf8mb4_unicode_520_ci	;
INSERT INTO `comments` VALUES 
(2,6,3,'Первий коментарий','2018-05-31 15:59:34'),
(6,4,3,'HI','2018-05-31 16:18:27'),
(7,4,3,'Привет Мир!','2018-06-01 10:23:56'),
(11,6,4,'Jena De','2018-06-06 12:26:32'),
(12,12,1,'123','2018-07-02 13:54:36'),
(14,13,1,'First comment !','2018-07-13 16:46:42'),
(17,13,3,'<h3>Иными словами, аллегро варьирует хамбакер, на этих моментах останавливаются Л.А.Мазель и В.А.Цуккерман в своем &quot;Анализе музыкальных произведений&quot;. Иными словами, мнимотакт начинает самодостаточный фьюжн, и здесь мы видим ту самую каноническую секвенцию с разнонаправленным шагом отдельных звеньев. Драм-машина mezzo forte варьирует паузный септаккорд. Громкостнoй прогрессийный период имеет нечетный соноропериод. Адажио начинает звукосниматель.</h3>\r\n','2018-07-21 17:51:46'),
(19,3,1,'<p><strong>veri nice view</strong></p>\r\n','2018-08-01 23:06:19'),
(23,9,12,'<p>kkk</p>\r\n\r\n<p>&nbsp;</p>\r\n','2018-08-03 19:26:03'),
(24,9,13,'<p>content&nbsp;</p>\r\n','2018-08-03 19:32:02')	;
#	TC`contacts`utf8_general_ci	;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `vk` varchar(255) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `github` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`contacts`utf8_general_ci	;
INSERT INTO `contacts` VALUES 
(1,'info@rightblock.ru','ironman','https://vk.com/dimitar76','https://www.facebook.com/dimitar.georgiev.77377692','+359878818754','11 Victoria Street, Belfast, UK Cathedral Qtr\r\n','Dimitar ','Georgiev                                    ','https://github.com/dimgeorgiev1976','https://twitter.com/Dvoenskok',43.627282,122.257714)	;
#	TC`jobs`utf8mb4_unicode_520_ci	;
CREATE TABLE `jobs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`jobs`utf8mb4_unicode_520_ci	;
INSERT INTO `jobs` VALUES 
(3,'сентябрь 2015 &mdash; январь 2017','Разработчик интерфейсов, Яндекс','Работы в проекте Яндекс Музыка. Создание новых разделов сервиса. Оптимизация и создание новых компонентов платформы.'),
(4,'март 2013 &mdash; август 2015','Веб-разработчик, Cloud studio','Frontend и Backend для клиентских проектов студии. Работа над студийной CMS для интернет магазинов. Участие в разработке CRM системы &ldquo;Sky CRM&rdquo;. Стек используемых технологий: Git, JS, Angular')	;
#	TC`messages`utf8mb4_unicode_520_ci	;
CREATE TABLE `messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci,
  `name` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message_file` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message_file_name_original` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`messages`utf8mb4_unicode_520_ci	;
INSERT INTO `messages` VALUES 
(1,'info@rightblog.ru','Privet','Dimitar Georgiev','1159061691.html',\N,\N),
(3,'info@rightblog.ru','Privet','Dimitar Georgiev','-423824867.html',\N,\N),
(4,'test@rightblog.ru','Hello!','Super_Dimi','568851902.html',\N,\N),
(5,'dvoen@rightblog.ru','HI!','Tony Stark','13806827.png','Photo.png',\N),
(6,'test@rightblog.ru','TEST @','Dimitar Georgiev','700378608.png',\N,\N),
(7,'dvoen@rightblog.ru','Prikrepen fail','Tony Stark','1150937634.pdf',\N,\N),
(8,'test@rightblog.ru','Fail message_file_name_original','Super_Dimi','1100355001.pdf','Transaction.pdf',\N),
(9,'info@rightblog.ru','New message date','Super_Dimi','1171929723.pdf','application802960107120.pdf','2018-06-23 08:55:39'),
(10,'ironman@gmail.com','profile/profile-edit.tpl','Tony ','167333717.jpg','arnaud-mesureur-186867-unsplash.jpg','2018-07-06 11:50:28'),
(16,'360456036@qq.com','\r\nQingzhu Li','Della','6157167.jpg','708621265.jpg','2018-08-01 23:24:54'),
(17,'dvoen@rightblog.ru','ssssss','Dimitar Georgiev','72157719.jpg','30582285_609744296040663_1231127975689191424_n.jpg','2018-08-30 15:04:52')	;
#	TC`posts`utf8mb4_unicode_520_ci	;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_520_ci,
  `post_img` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_img_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` int(11) unsigned DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `cat` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_posts_author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`posts`utf8mb4_unicode_520_ci	;
INSERT INTO `posts` VALUES 
(1,'Новый пост','<p>Введите город</p>\r\n','936213466.jpg','320-936213466.jpg',1,'2018-07-23 12:05:31',1532336731,'3'),
(2,'Новый пост','<h1>Реферат по музыковедению</h1>\r\n\r\n<p><strong>Тема: &laquo;Автономный лайн-ап: ретро или протяженность?&raquo;</strong></p>\r\n\r\n<p><big>Развивая эту тему, драм-машина диссонирует мнимотакт. Попса продолжает хорус, хотя это довольно часто напоминает <strong>песни Джима Моррисона и Патти Смит.</strong></big></p>\r\n','-263004115.jpg','320--263004115.jpg',1,'2018-07-21 16:56:34',1532181394,'3'),
(3,'Верстка и frontend Интернет магазина Длинны пост ','Введите город','-625088007.jpg','320--625088007.jpg',1,'2018-06-04 15:56:57',\N,'3'),
(4,'Новый пост # 4','Bogor','545606424.jpg','320-545606424.jpg',1,'2018-06-04 15:56:57',\N,'3'),
(5,'Новый пост # 5','<p>Yogiakarta</p>\r\n','1063470595.jpg','320-1063470595.jpg',1,'2018-06-04 15:56:57',\N,'1'),
(6,'Пpожил полтора года на Бали',' В прошлом спортсмен и серпентолог, я прожил полтора года на Бали, потом вернулся в Россию. И после серьезной подготовки Эдуард решил сделать тур по всей Индонезии. ','263221312.jpg','320-263221312.jpg',1,'2018-06-04 15:56:57',\N,'2'),
(7,'Hello, this is the first example, where I am going','','-451695720.jpg','320--451695720.jpg',1,'2018-06-04 15:56:57',\N,'2'),
(8,'Hello, this is the first example, where I am going to have a string that is over 50 characters and is super long','<p>Burgas</p>\r\n','383243880.jpg','320-383243880.jpg',1,'2018-07-13 16:45:39',1531489539,'2'),
(9,'Новый пост','Введите город','-193267682.JPG','320--193267682.JPG',1,'2018-06-05 14:57:51',\N,'3'),
(10,'Категория','China','-220249040.JPG','320--220249040.JPG',1,'2018-06-18 21:39:53',1529347193,'1'),
(11,'this is a long string that should be cut in the middle of the first \'that\'','<p>China</p>\r\n','-290341271.jpg','320--290341271.jpg',1,'2018-06-18 21:40:26',1529347226,'1'),
(12,' I don\'t know how long maybe around 1000 characters.I am going to have a string that is over 50 characters and is super long, ','<pre>\r\n<code>I am going to have a string that is over 50 characters and is super long, I don&#39;t know how long maybe around 1000 characters. </code></pre>\r\n','1208161832.jpg','320-1208161832.jpg',1,'2018-08-07 12:55:22',1533635722,'3'),
(13,'I am going to have a string that is over 50 characters and is super long, I don\'t know how long maybe around 1000 characters. ','<p>Парк находится в горах&nbsp;<a href=\"http://localhost:3000/ui-kit/full-post.html\">Сьерра-Невада&nbsp;</a>на востоке штата Калифорния и занимает огромную даже для Америки площадь, около 3000 кв. км. На этой площади расположены гранитные скальные стены огромной высоты, которыми, собственно, в первую очередь и знаменит парк, водопады, среди которых одни из самых высоких в США, три рощи гигантской секвойи &mdash; самого долгоживущего в мире дерева и самого большого по диаметру ствола, а также масса рек, озёр, лесов и лугов.</p>\r\n\r\n<p>Центром парка является долина&nbsp;<a href=\"http://localhost:3000/ui-kit/full-post.html\">Йосемити,&nbsp;</a>круглый год переполненная туристами, зато в большей части парка никаких туристов нет. Если вы хотите погулять по территории парка, к вашим услугам огромная разветвлённая система троп, по которым проложены маршруты длительностью от получаса до нескольких дней. Ко всем этим прелестям бесплатно прилагаются животные и птицы. Если, на ваше счастье, медведей вы скорее всего не увидите, то оленей или бурундуков увидите почти гарантированно, даже не обладая специальными навыками</p>\r\n','-303327902.png','320--303327902.png',1,'2018-08-11 14:12:57',1533985977,'3'),
(16,'I don\'t know how long maybe around 1000 characters. Anyway this should be over 50 characters know...&quot;;','<p>I don&#39;t know how long maybe around 1000 characters</p>\r\n','482511557.png','320-482511557.png',1,'2018-08-11 14:59:11',1533988751,'3')	;
#	TC`skills`utf8_general_ci	;
CREATE TABLE `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `html5` int(11) NOT NULL,
  `css3` int(11) NOT NULL,
  `js` int(11) NOT NULL,
  `jquery` int(11) NOT NULL,
  `php` int(11) NOT NULL,
  `mysql` int(11) NOT NULL,
  `git` int(11) NOT NULL,
  `gulp` int(11) NOT NULL,
  `bower` int(11) NOT NULL,
  `webpack` int(11) NOT NULL,
  `html` int(11) unsigned DEFAULT NULL,
  `css` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`skills`utf8_general_ci	;
INSERT INTO `skills` VALUES 
(1,50,0,80,60,60,10,60,10,90,60,50,'')	;
#	TC`technologies`utf8_general_ci	;
CREATE TABLE `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `success` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`technologies`utf8_general_ci	;
INSERT INTO `technologies` VALUES 
(1,'HTML5',100),
(2,'CSS3',100),
(3,'JS',75),
(4,'JQuery',75),
(5,'PHP',50),
(6,'MySQL',50),
(7,'Git',70),
(8,'Gulp',80),
(9,'Bower',90),
(10,'WebPack',20)	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `secundname` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `secondname` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `avatar_small` varchar(191) DEFAULT NULL,
  `recovery_code` varchar(191) DEFAULT NULL,
  `recovery_code_times` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'dvoen@rightblog.ru','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','Dimitar ','Georgiev','','China','Bogor','admin','Georgiev','551595692.jpg','48-551595692.jpg',\N,\N),
(2,'dvoenskok@gmail.com','$2y$10$LS9JGvoYdQpl15vjSWI6ru.FCqXbpREWUUlmJJANbWnBqR/aELaXe','Super_Dimi','','','China','Bogor','user','Georgiev','103527254.jpg','48-103527254.jpg','bAyIz2pqnoXJUgx',0),
(3,'ironman@gmail.com','$2y$10$Y2n2GmcyC.aauxXv93maEup8UYkzBQcGVcUh5lVw.N5YoktgVGBbm','taco','','','Ghana','Siatle','user','Stark','-256955547.png','48--256955547.png','bNmfuiswIcdUXPS',3),
(4,'info@rightblog.ru','$2y$10$p6gxwU2DTQD2Aqclt7aGdeU3JSN7AY//5agUZwbaxGM6lM0RyQKB.','John','','','Ghan','','user','Do','1017335438.jpg','48-1017335438.jpg','dAswxgXSyq1CWfu',3),
(5,'test@rightblog.ru','$2y$10$x50rEp.xVzTkcKYePPgAZ.dEA5mj62oSZisBrHc.IfcGYAQX8Oje.','Tony ','','','Russia','Bali','user','Stark','-316729632.jpg','48--316729632.jpg','Op3hUA6gmajbfND',3),
(6,'abtarar@email.ru','$2y$10$P6OH8QXM.OShX0beUTqyWeKmb3JQkgKI6h1K/RkwPFf.cDZA04EJC','Tony ','','','Russia','Siatle','user','Stark_Ok','-234421665.JPG','48--234421665.JPG',\N,\N),
(7,'111info@rightblog.ru','$2y$10$IXUdJLTyCatyMK96rsKAquSBTU6xelOGu6b5AK/qm.gZXrbSUMAgu','','','','','','user',\N,\N,\N,\N,\N),
(8,'123456info@rightblog.ru','$2y$10$guBEbZaiRUubKFH6wxs0SepXoDd.9jE22urK.LqY3VGpWcAYTuh0y','','','','','','user',\N,\N,\N,\N,\N),
(9,'123@rightblog.ru','$2y$10$.FL4.YzhfYpm3BylOyI4Je1gWi4coDgY3F1wqHz5fS6XJHEWxmYjO','','','','','','user',\N,\N,\N,\N,\N),
(10,'360456036@qq.com','$2y$10$5LsUoHDBcXleeBYM3eG8gO/OUFBkWKQT8ST.hPJrGNtVyCsNNX2r6','Qingzhu','','','China','Tongliao','user','Li','1146015760.jpg','48-1146015760.jpg',\N,\N),
(11,'321info@rightblog.ru','$2y$10$pKhr8lY1uGWtc3Dd0F76i.oI0tSje8UO/hgmjl5RguAzWVqcRSVQe','Tony Bony','','','China','Bogor','user','Georgiev555','-174766180.jpg','48--174766180.jpg',\N,\N),
(12,'987info@rightblog.ru','$2y$10$Su43qtoiMJwY9OWYm4lJUOvQQOgNyRB39GGBxRgw3VRqJdGbYVvwm','Tony 987','','','Russia','Bali','user','Georgiev555666','-559502552.jpg','48--559502552.jpg',\N,\N),
(13,'654info@rightblog.ru','$2y$10$YCmu/A/tck1cl/NJKo36s..F1eZw3.y4MvHzC9SSQ.w6WuK96ldRC','Super_Dimi654','','','','','user','Georgiev654','-375732821.png','48--375732821.png',\N,\N),
(14,'789info@rightblog.ru','$2y$10$wzTFgB.DfH98ajV60SjF0e2uAr3Jq3MczTARDVK/6cDIAdcgOqYBG','Dimitar 789','','','','','user','Georgiev 789','171188197.jpg','48-171188197.jpg',\N,\N)	;
#	TC`works`utf8mb4_unicode_520_ci	;
CREATE TABLE `works` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_520_ci,
  `author_id` int(11) unsigned DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `work_img` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `work_img_small` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `result` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `technologies` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `github` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `database` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_foreignkey_works_author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci	;
#	TD`works`utf8mb4_unicode_520_ci	;
INSERT INTO `works` VALUES 
(1,'Верстка Landing Page # 3','Сделана верстка Page # 3 ',1,'2018-07-28 14:54:47','168697610.jpg','320-168697610.jpg','Result # 3','<p>Технологии# 3</p>\r\n','','',\N),
(2,'Интернет магазина Page # 5','Сделана верстка Page # 4    ',1,'2018-07-28 14:57:37','-422164476.jpg','320--422164476.jpg','Результат Page # 4','<p>Технологии Page # 4</p>\r\n','','',\N),
(3,'Верстка и frontend Интернет магазина ','Сделана верстка  ',1,'2018-07-29 00:32:31','-480693268.jpg','320--480693268.jpg','Проект сделан в срок. Заказчик доволен. Сайт запущен, работает и уже радует покупками посетителей и владельцев бизнеса.','<ul>\r\n	<li>HTML5, CSS3.</li>\r\n	<li>JavaScript, jQuery.</li>\r\n	<li>Less, Pug, Gulp, npm, bower.</li>\r\n</ul>\r\n','http://magnum-store.ru','https://github.com/pozitive/magnumstore/',\N),
(4,'Верстка и frontend Интернет магазина','Сделана верстка  ',1,'2018-08-01 17:52:04','-685810887.jpg','320--685810887.jpg','Сайт запущен, работает и уже радует покупками посетителей и владельцев бизнеса.\r\n\r\n\r\n','<p>HTML5, CSS3.<br />\r\nJavaScript, jQuery.<br />\r\nLess, Pug, Gulp, npm, bower.</p>\r\n','','','')	;
